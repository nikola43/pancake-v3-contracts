# Solidity API

## SmartRouter

### constructor

```solidity
constructor(address _factoryV2, address _deployer, address _factoryV3, address _positionManager, address _stableFactory, address _stableInfo, address _WETH9) public
```

