# Solidity API

## ISmartRouter

